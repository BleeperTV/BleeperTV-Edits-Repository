import urllib.request, urllib.parse, urllib.error
import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs
from resources.lib.BleeperTvUtilities import BleeperTvServer, log

__addon__ = xbmcaddon.Addon()
__scriptname__ = __addon__.getAddonInfo('name')
__addon_id__ = __addon__.getAddonInfo('id')
__language__   = __addon__.getLocalizedString
__cwd__        = xbmcvfs.translatePath( __addon__.getAddonInfo('path') )

ignored_for_now = False

previous_settings = xbmcaddon.Addon().getSettings()

def test_login():
    settings = xbmcaddon.Addon().getSettings()
    if not settings.getString("user") or not settings.getString("pass"):
        return

    try:
        BleeperTvServer()
        xbmc.executebuiltin('Notification(%s,%s,%s,%s/icon.png)' % (__scriptname__ , "Logged in successfully", "5000",__cwd__))
    except urllib.error.HTTPError as e:
        if e.code == 400:
            log( __name__, "failed to login to service")
            log( __name__, e)
            xbmc.executebuiltin('Notification(%s,%s,%s,%s/icon.png)' % (__scriptname__ , "Invalid credentials", "5000",__cwd__))
            xbmc.executebuiltin('Addon.OpenSettings(%s)' % __addon_id__)
        else:
            xbmc.executebuiltin('Notification(%s,%s,%s,%s/icon.png)' % (__scriptname__ , "Unexpected error", "5000",__cwd__))
    except Exception as e:
        log( __name__, "failed to login to service")
        log( __name__, e)
        xbmc.executebuiltin('Notification(%s,%s,%s,%s/icon.png)' % (__scriptname__ , "Failed to connect to BleeperTV", "5000",__cwd__))
        return
    
def check_empty_credentials():
    settings = xbmcaddon.Addon().getSettings()

    if settings.getBool('enable_credentials_missing_dialog') \
            and not ignored_for_now \
            and (not settings.getString("user") or not settings.getString("pass")):
        res = xbmcgui.Dialog().yesnocustom(
            'BleeperTV credentials missing',
            'It seems you have not yet configured your BleeperTV credentials. Would you like to do that now?',
            "Don't ask again",
            defaultbutton=xbmcgui.DLG_YESNO_YES_BTN,
        )
        if res == 1: # yes
            xbmc.executebuiltin('Addon.OpenSettings(%s)' % __addon_id__)
        elif res == 2: # don't ask again
            xbmcaddon.Addon().setSettingBool('enable_credentials_missing_dialog', False)

def credentials_changed():
    settings = xbmcaddon.Addon().getSettings()
    return previous_settings.getString('user') != settings.getString('user') \
        or previous_settings.getString('pass') != settings.getString('pass')

class BackgroundService(xbmc.Monitor):
    def onSettingsChanged(self):
        check_empty_credentials()
        if credentials_changed():
            test_login()
        global previous_settings
        previous_settings = xbmcaddon.Addon().getSettings()

if __name__ == '__main__':
    monitor = BackgroundService()
    check_empty_credentials()

    while not monitor.abortRequested():
        if monitor.waitForAbort(10):
            break
