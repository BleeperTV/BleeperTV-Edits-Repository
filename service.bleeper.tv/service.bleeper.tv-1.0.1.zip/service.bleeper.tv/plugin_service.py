import os
import sys
import urllib.request, urllib.parse, urllib.error
import xbmc
import xbmcgui
import xbmcvfs
import xbmcaddon
import xbmcplugin
from urllib.parse import parse_qsl


__addon__ = xbmcaddon.Addon()
__scriptname__ = __addon__.getAddonInfo('name')
__language__   = __addon__.getLocalizedString
__cwd__        = xbmcvfs.translatePath( __addon__.getAddonInfo('path') )

from resources.lib.BleeperTvUtilities import BleeperTvServer, log

# Get the plugin url in plugin:// notation.
__url__ = sys.argv[0]
# Get the plugin handle as an integer number.
__handle__ = int(sys.argv[1])

# action constants
SEARCH = 0
LIST_MEDIA = 1
VIEW_MEDIA_ENTRY = 2
SETTINGS = 3
ADDONS = 4
INSTALL_ADDON = 5
CONFIG = 6

WATCH_PROVIDER_TYPES = ['flatrate', 'free', 'ads', 'rent', 'buy']

# the program action
action = -1
params = dict(parse_qsl(sys.argv[2][1:]))

if('menu' in params):
    if(params['menu'] == 'search'):
        action = SEARCH
    elif(params['menu'] == 'list_media'):
        action = LIST_MEDIA
    elif(params['menu'] == 'view_media_entry'):
        action = VIEW_MEDIA_ENTRY
    elif(params['menu'] == 'addons'):
        action = ADDONS
    elif(params['menu'] == 'install_addon'):
        action = INSTALL_ADDON
    elif(params['menu'] == 'config'):
        action = CONFIG
    else:
        raise "Unknown menu"

provider_id_to_addon = {
    8: 'plugin.video.netflix', # Netflix
    175: 'plugin.video.netflix', # Netflix Kids
    1796: 'plugin.video.netflix', # Netflix with ads
    9: 'plugin.video.amazon-test', # Amazon Prime Video
    10: 'plugin.video.amazon-test', # Amazon Video
    1825: 'plugin.video.amazon-test', # Max Amazon Channel
    583: 'plugin.video.amazon-test', # MGM Plus Amazon Channel
    582: 'plugin.video.amazon-test', # Paramount+ Amazon Channel
    194: 'plugin.video.amazon-test', # Starz Play Amazon Channel
    584: 'plugin.video.amazon-test', # Discovery+ Amazon Channel
    528: 'plugin.video.amazon-test', # AMC+ Amazon Channel
    203: 'plugin.video.amazon-test', # Showtime Amazon Channel
    262: 'plugin.video.amazon-test', # Noggin Amazon Channel
    293: 'plugin.video.amazon-test', # PBS Kids Amazon Channel
    288: 'plugin.video.amazon-test', # Boomerang Amazon Channel
    289: 'plugin.video.amazon-test', # Cinemax Amazon Channel
    292: 'plugin.video.amazon-test', # Pantaya Amazon Channel
    290: 'plugin.video.amazon-test', # Hallmark Movies Now Amazon Channel
    294: 'plugin.video.amazon-test', # PBS Masterpiece Amazon Channel
    295: 'plugin.video.amazon-test', # Viewster Amazon Channel
    291: 'plugin.video.amazon-test', # MZ Choice Amazon Channel
    204: 'plugin.video.amazon-test', # Shudder Amazon Channel
    201: 'plugin.video.amazon-test', # MUBI Amazon Channel
    197: 'plugin.video.amazon-test', # BritBox Amazon Channel
    196: 'plugin.video.amazon-test', # AcornTV Amazon Channel
    199: 'plugin.video.amazon-test', # Fandor Amazon Channel
    202: 'plugin.video.amazon-test', # Screambox Amazon Channel
    205: 'plugin.video.amazon-test', # Sundance Now Amazon Channel
    343: 'plugin.video.amazon-test', # Bet+ Amazon Channel
    263: 'plugin.video.amazon-test', # DreamWorksTV Amazon Channel
    688: 'plugin.video.amazon-test', # ShortsTV Amazon Channel
    1794: 'plugin.video.amazon-test', # Starz Amazon Channel
    1811: 'plugin.video.amazon-test', # Cohen Media Amazon Channel
    597: 'plugin.video.amazon-test', # Full Moon Amazon Channel
    337: 'slyguy.disney.plus',
    386: 'plugin.video.skyott', # Peacock
    387: 'plugin.video.skyott', # Peacock Premium
    37: 'plugin.video.skyott', # Showtime
    12: 'plugin.video.crackle',
    531: 'slyguy.paramount.plus', # Paramount Plus
    1770: 'slyguy.paramount.plus', # Paramount+ with Showtime
    1853: 'slyguy.paramount.plus', # Paramount Plus Apple TV Channel
    633: 'slyguy.paramount.plus', # Paramount+ Roku Premium Channel
    15: 'slyguy.hulu',
    1899: 'slyguy.hbo.max', # Max
    1955: 'slyguy.hbo.max', # BR Sports
}

is_folder = True
is_not_folder = False

if(action == -1):
    xbmcplugin.addDirectoryItem(__handle__, '{0}?menu=search&media_type=movies'.format(__url__), xbmcgui.ListItem(__language__(32007)), is_folder)
    xbmcplugin.addDirectoryItem(__handle__, '{0}?menu=list_media&media_type=movies'.format(__url__), xbmcgui.ListItem(__language__(32008)), is_folder)
    xbmcplugin.addDirectoryItem(__handle__, '{0}?menu=search&media_type=tv-shows'.format(__url__), xbmcgui.ListItem(__language__(32009)), is_folder)
    xbmcplugin.addDirectoryItem(__handle__, '{0}?menu=list_media&media_type=tv-shows'.format(__url__), xbmcgui.ListItem(__language__(32010)), is_folder)
    xbmcplugin.addDirectoryItem(__handle__, '{0}?menu=addons'.format(__url__), xbmcgui.ListItem('Streaming Addons'), is_folder)
    xbmcplugin.addDirectoryItem(__handle__, '{0}?menu=config'.format(__url__), xbmcgui.ListItem('Settings'), is_folder)
    xbmcplugin.endOfDirectory(__handle__)
    xbmc.executebuiltin('Container.SetViewMode(55)')

def get_media(media_type, query):
    try:
        server = BleeperTvServer()
    except urllib.error.HTTPError as e:
        if e.code == 400:
            log( __name__, "failed to login to service")
            log( __name__, e)
            xbmcgui.Dialog().ok(__language__(32001),__language__(32005))
            return
        raise e
    except Exception as e:
        log( __name__, "failed to login to service")
        log( __name__, e)
        xbmc.executebuiltin('Notification(%s,%s,%s,%s/icon.png)' % (__scriptname__ , __language__(32001),"5000",__cwd__))
        return
    return server.search_media(media_type, query)

def fetch_media_details(media_type, media_id):
    server = BleeperTvServer()
    return server.fetch_media_details(media_type, media_id)

def search_and_list_media(media_type, query):
    media = get_media(media_type, query)
    if media:
        for entry in media:
            list_item = xbmcgui.ListItem(label=entry['name'])
            list_item.setInfo('video', {'title': entry['name']})
            image_url = entry.get('image', {}).get('url')
            list_item.setArt({'thumb': image_url, 'icon': image_url, 'fanart': image_url})
            url = '{0}?menu=view_media_entry&media_type={1}&media_id={2}'.format(__url__, media_type, entry['id'])
            xbmcplugin.addDirectoryItem(__handle__, url, list_item, is_folder)
        xbmcplugin.endOfDirectory(__handle__)
        xbmc.executebuiltin('Container.SetViewMode(55)')
    else:
        xbmc.executebuiltin('Notification(%s,%s,%s,%s/icon.png)' % (__scriptname__, __language__(32011), "5000", __cwd__))

def view_media_entry(media_type, media_id):
    entry = fetch_media_details(media_type, media_id)
    watch_providers = dict()
    media_country = 'US'
    if (media_country in entry['watchProviders']):
        country_watch_providers_obj = entry['watchProviders'][media_country]
        for provider_type in WATCH_PROVIDER_TYPES:
            if (provider_type in country_watch_providers_obj):
                for entry in country_watch_providers_obj[provider_type]:
                    entry['provider_types'] = list()
                    provider_id = entry['provider_id']
                    if provider_id not in watch_providers:
                        watch_providers[provider_id] = entry
                    watch_providers[provider_id]['provider_types'].append(provider_type)
    watch_providers_list = list(watch_providers.values())
    watch_providers_list.sort(key=lambda provider: provider['display_priority'])
    if watch_providers_list:
        for provider in watch_providers_list:
            image_url = f"https://image.tmdb.org/t/p/original{provider['logo_path']}"
            provider_id = provider['provider_id']
            list_item = xbmcgui.ListItem(label=f"{provider['provider_name']} ({'/'.join(provider['provider_types'])})", offscreen=True)
            list_item.setArt({'thumb': image_url, 'icon': image_url})
            is_known_provider = provider_id in provider_id_to_addon
            url = 'plugin://{}/'.format(provider_id_to_addon[provider_id]) if is_known_provider else None
            xbmcplugin.addDirectoryItem(__handle__, url, list_item, is_known_provider)
        xbmcplugin.endOfDirectory(__handle__)
        xbmc.executebuiltin('Container.SetViewMode(52)')
    else:
        xbmcgui.Dialog().ok('BleeperTV', 'No watch providers available for the selected media and configured country.')

def list_addons():
    list_addon('plugin.video.crackle', 'Crackle', 'repository.xbmc.org')
    list_addon('plugin.googledrive', 'Google Drive', 'repository.xbmc.org')
    list_addon('plugin.onedrive', 'OneDrive', 'repository.xbmc.org')
    list_addon('plugin.video.netflix', 'Netflix', 'repository.castagnait')
    list_addon('plugin.video.amazon-test', 'Amazon Prime Video', 'repository.sandmann79.plugins')
    list_addon('plugin.video.skyott', 'SkyOtt (SkyShowtime / PeacockTV)', 'repository.addons.paco8')
    list_addon('slyguy.disney.plus', 'Disney+', 'repository.slyguy')
    list_addon('slyguy.paramount.plus', 'Paramount+', 'repository.slyguy')
    list_addon('slyguy.hulu', 'Hulu', 'repository.slyguy')
    # list_addon('slyguy.hbo.max', 'HBO Max', 'repository.slyguy')
    xbmcplugin.endOfDirectory(__handle__)
    xbmc.executebuiltin('Container.SetViewMode(55)')

def list_addon(name, display_name, addon_repository):
    is_enabled = xbmc.getCondVisibility('System.AddonIsEnabled({0})'.format(name))
    list_item = xbmcgui.ListItem(label=display_name + (" (installed)" if is_enabled else "") )
    icon = os.path.join(__cwd__, 'resources', 'media','addon_icons', '{0}.png'.format(name))
    list_item.setArt({ 'icon': icon })
    url = '{0}?menu=install_addon&addon={1}&addon_repository={2}'.format(__url__, name, addon_repository)
    xbmcplugin.addDirectoryItem(__handle__, url, list_item, is_not_folder)

def install_addon(name):
    res = xbmc.executebuiltin('InstallAddon({0})'.format(name), True)
    if not res:
        res = xbmc.getCondVisibility('System.AddonIsEnabled({0})'.format(name))
        if not res:
            res = xbmc.executebuiltin('EnableAddon({0})'.format(name), True)
    return xbmc.getCondVisibility('System.AddonIsEnabled({0})'.format(name))

# check which action should be run
if (action != -1):
    if (action == SEARCH):
        titles = {
            'movies': __language__(32007),
            'tv-shows': __language__(32009),
        }
        query = xbmcgui.Dialog().input(titles[params['media_type']])
        if (query):
            search_and_list_media(params['media_type'], query)
    elif (action == LIST_MEDIA):
        search_and_list_media(params['media_type'], '')
    elif (action == VIEW_MEDIA_ENTRY):
        view_media_entry(params['media_type'], params['media_id'])
    elif (action == ADDONS):
        list_addons()
    elif (action == CONFIG):
        __addon__.openSettings()
    elif (action == INSTALL_ADDON):
        already_installed = xbmc.getCondVisibility('System.AddonIsEnabled({0})'.format(params['addon']))
        if already_installed:
            xbmc.executebuiltin('Container.Update(plugin://%s/)' % params['addon'])
        else:
            res = True
            if not xbmc.getCondVisibility('System.AddonIsEnabled({0})'.format(params['addon_repository'])):                          
                res = install_addon(params['addon_repository'])
                xbmc.executebuiltin('UpdateAddonRepos', True)
                xbmc.sleep(1000)
            if res:
                res = install_addon(params['addon'])
            if res:
                xbmc.executebuiltin('Container.Update({}?menu=addons)'.format(__url__))
    else:
        raise "Unknown action"
