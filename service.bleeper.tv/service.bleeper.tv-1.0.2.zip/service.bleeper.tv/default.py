import sys
from urllib.parse import parse_qsl

params = dict(parse_qsl(sys.argv[2][1:]))

if ('action' in params):
    import subtitle_service
else:
    import plugin_service
