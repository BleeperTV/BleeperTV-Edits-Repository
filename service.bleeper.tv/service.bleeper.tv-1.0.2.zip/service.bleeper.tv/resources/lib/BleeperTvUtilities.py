# -*- coding: utf-8 -*- 

import os
import sys
import xbmc
import struct
import urllib.request, urllib.parse, urllib.error
import xbmcvfs
import urllib.request, urllib.error, urllib.parse
import json
import xbmcaddon
import unicodedata

__addon__      = xbmcaddon.Addon()
__version__    = __addon__.getAddonInfo('version') # Module version
__scriptname__ = "XBMC Subtitles Unofficial"

BASE_URL = "https://bleeper.tv/api/"

class BleeperTvServer:
  def __init__( self, *args, **kwargs ):
    login = self.login(__addon__.getSetting( "user" ), __addon__.getSetting( "pass" ))
    log('login', 'login successful')
    self.jwt_token  = login['jwt']

  def http_get(self, url, params = {}):
    encoded_params = urllib.parse.urlencode(params)
    full_url = '{0}?{1}'.format(url, encoded_params)
    log('url', full_url)
    req = urllib.request.Request(full_url, headers={'Authorization': 'Bearer ' + self.jwt_token})
    content = urllib.request.urlopen(req).read()
    log('content', json.loads(content))
    return json.loads(content)

  def login(self, username, password):
    url = BASE_URL + 'auth/local'
    data = urllib.parse.urlencode({'identifier': username, 'password': password})
    req = urllib.request.Request(url, data.encode("utf-8"))
    content = urllib.request.urlopen(req).read()
    return json.loads(content)
  
  def search_media(self, media_type, query):
    return self.http_get(BASE_URL + media_type, params={'_q': query})
  
  def fetch_media_details(self, media_type, media_id):
    return self.http_get(BASE_URL + media_type + '/' + media_id)

  def searchsubtitles( self, item):
    if item['mansearch']:
      return self.http_get(BASE_URL + 'edl', params={'_q': urllib.parse.unquote(item['mansearchstr'])})

    query_parts = []

    if len(item['tvshow']) > 0:
      query_parts.append("%s S%.2dE%.2d" % (item['tvshow'],
                                            int(item['season']),
                                            int(item['episode'])))
    else:
      if str(item['year']) == "" and xbmc.Player().isPlaying():
        item['title'], item['year'] = xbmc.getCleanMovieTitle( item['title'] )
  
      query_parts.append("%s %s" % (item['title'], item['year']))

    if not item['temp']:
      if xbmc.Player().isPlaying():
          imdb = str(xbmc.Player().getVideoInfoTag().getUniqueID("imdb").replace('tt',''))
      else:
          imdb = str(xbmc.getInfoLabel("ListItem.IMDBNumber").replace('tt',''))
      if (imdb != ""):
        query_parts.append(imdb)

    query = ' '.join(query_parts)

    log( __name__ , "Query [ %s ]" % (query,))

    return self.http_get(BASE_URL + 'edl', params={'_q': query})

def log(module, msg):
  xbmc.log("### [%s] - %s" % (module,msg,),level=xbmc.LOGDEBUG ) 

def log_error(module, msg):
  xbmc.log("### [%s] - %s" % (module,msg,),level=xbmc.LOGERROR ) 

def normalizeString(input_str):
  return unicodedata.normalize(
    'NFKD', input_str).encode(
      'ascii', 'ignore').decode('utf-8')
